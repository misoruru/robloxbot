import requests
import time
import pyautogui
import os
from pynput.keyboard import Controller, Key
file_path = os.path.abspath("command.wav")


def send_groq_request(transcript_ttext):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer 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",
        "Content-Type": "application/json"
    }

    prompt = f"""
    ТЫ ИГРАЕШЬ РОЛЬ ИГРОВОГО БОТА В РОБЛОКСЕ, ТЫ КОЛОНКА И ТЕБЕ ЧЕЛОВЕК ДАЛ ЗАПРОС {transcript_ttext}
    ОТВЕТЬ НА ЭТОТ ВОПРОС ДРУЖЕЛЮБНО НО С ЮМОРОМ И НЕ БОЛЬШЕ 15 СЛОВ И ГОВОРИ ТАК ЧТО БЫ ТЕБЯ НЕ ЗАБЛЮРИЛ РОБЛОКС
    """

    payload = {
        "model": "meta-llama/llama-4-scout-17b-16e-instruct",
        "messages": [{"role": "user", "content": prompt}]
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data.get('choices', [{}])[0].get('message', {}).get('content', '').strip()
    except requests.exceptions.RequestException as e:
        print(f"Ошибка API: {e}")
        return None

keyboard = Controller()

def use_keyboard_to_send(text):
    time.sleep(2)  # Даём 2 секунды на переключение в Roblox

    # Нажимаем .
    keyboard.press('/')
    keyboard.release('/')
    time.sleep(0.3)

    # Печатаем текст по одному символу
    for char in text:
        keyboard.press(char)
        keyboard.release(char)
        time.sleep(0.02)  # Небольшая задержка между символами (можно убрать)

    time.sleep(0.3)

    # Нажимаем Enter
    keyboard.press(Key.enter)
    keyboard.release(Key.enter)

