import time
import ctypes
import os
from ctypes import wintypes
from ultralytics import YOLO
from PIL import Image, ImageGrab, ImageDraw

# --- Windows API для управления мышью ---
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010

user32 = ctypes.WinDLL('user32', use_last_error=True)
GetSystemMetrics = user32.GetSystemMetrics
mouse_event = user32.mouse_event

screen_width = GetSystemMetrics(0)
screen_height = GetSystemMetrics(1)

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

def get_cursor_pos():
    pt = POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y

def move_mouse_absolute(x, y):
    abs_x = int(x * 65535 / screen_width)
    abs_y = int(y * 65535 / screen_height)
    mouse_event(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, abs_x, abs_y, 0, 0)

def smooth_move(x_start, y_start, x_end, y_end, steps=30, delay=0.01):
    for i in range(steps + 1):
        x = x_start + (x_end - x_start) * i / steps
        y = y_start + (y_end - y_start) * i / steps
        move_mouse_absolute(int(x), int(y))
        time.sleep(delay)

def left_click():
    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    time.sleep(0.05)
    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)

def right_click():
    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
    time.sleep(0.05)
    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)

def scroll_right_with_right_click(scroll_pixels=300, step=10, delay=0.01):
    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
    time.sleep(0.05)
    for _ in range(scroll_pixels // step):
        mouse_event(MOUSEEVENTF_MOVE, step, 0, 0, 0)
        time.sleep(delay)
    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)

def grab_screen_exclude_center_and_borders(exclude_width=200, exclude_height=400, border=50):
    center_x = screen_width // 2
    center_y = screen_height // 2

    left_center = center_x - exclude_width // 2
    right_center = center_x + exclude_width // 2
    top_center = center_y - exclude_height // 2
    bottom_center = center_y + exclude_height // 2

    top_area = ImageGrab.grab(bbox=(border, border, screen_width - border, top_center))
    bottom_area = ImageGrab.grab(bbox=(border, bottom_center, screen_width - border, screen_height - border))
    left_area = ImageGrab.grab(bbox=(border, top_center, left_center, bottom_center))
    right_area = ImageGrab.grab(bbox=(right_center, top_center, screen_width - border, bottom_center))

    result = Image.new('RGB', (screen_width, screen_height))

    result.paste(top_area, (border, border))
    result.paste(bottom_area, (border, bottom_center))
    result.paste(left_area, (border, top_center))
    result.paste(right_area, (right_center, top_center))

    draw = ImageDraw.Draw(result)
    draw.rectangle([0, 0, screen_width, border], fill=(0,0,0))
    draw.rectangle([0, screen_height - border, screen_width, screen_height], fill=(0,0,0))
    draw.rectangle([0, 0, border, screen_height], fill=(0,0,0))
    draw.rectangle([screen_width - border, 0, screen_width, screen_height], fill=(0,0,0))
    draw.rectangle([left_center, top_center, right_center, bottom_center], fill=(0,0,0))

    return result

def find_object_coords(model, screenshot_path, conf_threshold=0.7):
    results = model(screenshot_path)
    if results and results[0].boxes is not None and len(results[0].boxes) > 0:
        for box in results[0].boxes:
            conf = box.conf[0].cpu().item()
            if conf >= conf_threshold:
                xyxy = box.xyxy[0].cpu().numpy()
                x_center = int((xyxy[0] + xyxy[2]) / 2)
                y_center = int((xyxy[1] + xyxy[3]) / 2)
                return x_center, y_center
    return None

def run_object_finder(model_path=os.path.abspath("best.pt"), screenshot_path=os.path.abspath("screenshot.png")):

    model = YOLO(model_path)

    while True:
        img = grab_screen_exclude_center_and_borders(exclude_width=200, exclude_height=400, border=50)
        img.save(screenshot_path)

        coords = find_object_coords(model, screenshot_path, conf_threshold=0.7)

        if coords is not None:
            x_center, y_center = coords
            print(f"Found object at: {x_center}, {y_center}")

            x_start, y_start = get_cursor_pos()
            smooth_move(x_start, y_start, x_center, y_center, steps=50, delay=0.005)
            time.sleep(3)

            
            right_click()

            break
        else:
            print("Объекты с confidence ≥ 0.6 не найдены. Прокручиваем вправо и пробуем снова.")
            scroll_right_with_right_click()
            time.sleep(0.5)

run_object_finder()
