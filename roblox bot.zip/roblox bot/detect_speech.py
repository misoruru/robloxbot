import whisper
import sounddevice as sd
import numpy as np
import scipy.io.wavfile
import time
from detect_go import go_to_player
from speech_to_text import get_transcript
from ask_groq import send_groq_request, use_keyboard_to_send
model = whisper.load_model("base")
TRIGGER_WORDS = ["алиса", "алекса"]
GO_WORD = "сюда"

fs = 32000
duration = 3  # секунда

def record(duration=1):
    audio = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int32')
    sd.wait()
    return audio

def save_wav(audio, filename="temp.wav"):
    scipy.io.wavfile.write(filename, fs, audio)

def listen_for_trigger():
    print("🎧 Жду команду ('Алиса', 'Алекса' или 'Сюда')...")
    while True:
        audio = record(duration)
        save_wav(audio, "trigger.wav")
        result = model.transcribe("trigger.wav", language="ru")
        print("🗣️", result["text"])

        lowered = result["text"].lower()
        if any(word in lowered for word in TRIGGER_WORDS):
            print("🚨 Триггер найден! Начинаю запись команды...")
            return "trigger"
        elif GO_WORD in lowered:
            print("📍 Услышал 'сюда'! Ищу игрока...")
            go_to_player()
            time.sleep(5)
            return "go"


def record_command():
    audio = record(duration=10)  # записываем 5 секунд
    save_wav(audio, "command.wav")

