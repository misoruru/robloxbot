# import subprocess
import time
import os
from detect_speech import listen_for_trigger, record_command
from speech_to_text import get_transcript
from ask_groq import send_groq_request, use_keyboard_to_send
from detect_go import go_to_player  # или object_finder

def main():
    while True:
        
        command_type = listen_for_trigger()

        if command_type == "trigger":
            record_command()
            file_path = os.path.abspath("command.wav")
            transcript_text = get_transcript(file_path)
            print("📜 Текст команды:", transcript_text)

            response = send_groq_request(transcript_text)
            if response:
                print("🤖 Ответ Groq:", response)
                use_keyboard_to_send(response)

        elif command_type == "go":
            go_to_player()

        print("🔁 Ожидание следующей команды...\n")
        time.sleep(1)

if __name__ == "__main__":
    main()