from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
file_path = os.path.abspath("command.wav")
def get_transcript(file_path):
    chrome_options = Options()
    chrome_options.add_argument("--incognito")
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(options=chrome_options)

    try:
        driver.get("https://www.clipto.com/transcribe-audio-video-to-text-free")

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "upload-input"))
        )
        upload_input = driver.find_element(By.ID, "upload-input")
        upload_input.send_keys(file_path)
        time.sleep(10)
        paragraph = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "p.mb-4"))
        )

        return paragraph.text

    finally:
        driver.quit()

ca = get_transcript(file_path)
print(ca)
